from setuptools import setup

setup(
    name='deepcallib',
    version='0.1',
    packages=['deepcallib'],
    install_requires=[
        # List your dependencies here
    ],
)